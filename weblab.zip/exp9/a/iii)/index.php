<html>

<body bgcolor="thistle">
    <form action="home.php" method="post">
        <b>
            <font color="blue" size="10">Login</font>
        </b>
        <br><br>
        User name: <br><input type="text" name="name"><br><br>
        Age: <br><input type="text" name="age"><br><br>
        <input type="submit" value="Login">
    </form>
</body>

</html>